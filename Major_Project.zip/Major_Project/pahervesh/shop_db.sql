-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2023 at 05:26 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pid`, `name`, `price`, `quantity`, `image`) VALUES
(58, 39, 35, 'Dress', 600, 2, 'm-western-dress-glamoda-original-imagtmh7jyaj4wpg.webp');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `user_id`, `name`, `email`, `number`, `message`) VALUES
(8, 34, 'Rohit', 'rohitchangani111@gmail.com', '8780149265', 'Hello..\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `number`, `email`, `method`, `address`, `total_products`, `total_price`, `placed_on`, `payment_status`) VALUES
(13, 34, 'Rohit', '08780149263', 'rohitchangani111@gmail.com', 'cash on delivery', 'flat no. rk rk rajkot gujrat India - 360020', ', Tshirt ( 1 )', 100, '10-Aug-2023', 'completed'),
(15, 39, 'Rohit Patel', '8780149265', 'rohitchangani23@gamil.com', 'credit card', 'flat no. 1 rku rajkot gujrat india - 360020', ', Sari ( 1 )', 100, '01-Oct-2023', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `details` varchar(500) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `details`, `price`, `image`) VALUES
(28, 'mens hoodies', 'Mens', 'Men Printed Hooded Neck Cotton Blend Black hoodies', 200, 'm-tshirthood-stone-black-smartees-original-imaghqf9jgbsvuqh.webp'),
(30, 'CYPHUS', 'Mens', 'Men Regular Fit Grey Cotton Blend Trousers', 350, '32-cyfor-f-cyphus-original-imag6yzhz8kfsfpr-bb.webp'),
(31, 'Kurta', 'Mens', 'Men Solid Pure Cotton Straight Kurta  (White)', 350, 'l-kcku-only-kurta-print-moon-fubar-original-imagq45zgzqrzzsc.webp'),
(32, 'Women Kurta', 'Womens', 'Women Printed Crepe Straight Kurta  (Light Green)', 150, 'xl-530302-1-stop-fashion-original-imag8d6rnet523dy.webp'),
(33, 'Lehenga Choli ', 'Womens', 'Floral Print Semi Stitched Lehenga Choli  (Green)\r\n', 500, 'free-sleeveless-fidera-organza-fabcartz-original-imagfgrsk8rz92aq.webp'),
(34, 'Blue Jeans', 'Womens', 'Women Flared High Rise Blue Jeans', 450, '28-kttladiesjeans854-kotty-original-imags7tess6zjqjx.webp'),
(35, 'Dress', 'Womens', 'Women A-line Pink Dress', 600, 'm-western-dress-glamoda-original-imagtmh7jyaj4wpg.webp'),
(36, 'Track Pants', 'Womens', 'Women Solid Black Track Pants\r\n', 280, '28-tt-06-black-q-rious-original-imaghs2fbd6mrfxh.webp'),
(37, 'Saree', 'Womens', 'Woven Cotton Silk Saree  (Blue, Beige)', 259, 'free-2810s2056ja-siril-unstitched-original-imagt88yvztnbuvj.webp'),
(38, 'T-Shirt', 'Mens', 'Men Printed, Typography Round Neck Cotton Blend Black T-Shirt', 159, 'l-st-theboys-black-smartees-original-imagnqszzzzyuzru.webp'),
(39, 'Formal Shirt', 'Mens', 'Men Slim Fit Solid Spread Collar Formal Shirt', 359, 's-r-sky-blue-stoneberg-original-imageum8actkhttm.webp'),
(40, 'Casual Shirt', 'Mens', 'Men Regular Fit Checkered Spread Collar Casual Shirt', 249, 's-shirt6042-tanip-original-imagskuvgfhyycz5.webp'),
(41, 'Cargos', 'Mens', 'Men Cargos', 700, '32-z1-cargo-black-zaysh-original-imagrs3yzhsthgnh.webp'),
(42, 'Kids  T-Shirt', 'Children', 'Boys Typography, Printed Cotton Blend T Shirt  (Black)', 185, '5-6-years-fc8111-black-fastcolors-original-imagnq9xzx59kkvq.webp'),
(43, 'Frocks', 'Children', 'Partywear Pink Floral Printed Frocks & Dresses For Girls', 199, 'd6xxn_512.webp'),
(44, 'Kids Jacket', 'Children', 'Boys Printed Denim Jacket', 445, '6-7-years-no-03-boysdenmlionprntdjktblack-blast-mysha-clothing-original-imagsfagnxyhmktv.webp'),
(45, 'Denim Jacket', 'Children', 'Girls Washed Denim Jacket', 335, '5-6-years-no-vn-kids-denim-leetos-original-imaghnx2ugwhqmxa.webp');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`, `image`) VALUES
(39, 'Rohit  ', 'changani23@gamil.com', '12345', 'user', 'img.jpeg'),
(40, 'admin', 'admin@gmail.com', '123', 'admin', 'img.jpeg'),
(44, 'vandan', 'vandan@gmail.com', '12345', 'user', '2.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
