
<?php

$QR_BASEDIR = dirname(__FILE__).DIRECTORY_SEPARATOR;
// Required libs
include $QR_BASEDIR."phpqrcode/qrconst.php";
include $QR_BASEDIR."phpqrcode/qrconfig.php";
include $QR_BASEDIR."phpqrcode/qrtools.php";
include $QR_BASEDIR."phpqrcode/qrspec.php";
include $QR_BASEDIR."phpqrcode/qrimage.php";
include $QR_BASEDIR."phpqrcode/qrinput.php";
include $QR_BASEDIR."phpqrcode/qrbitstream.php";
include $QR_BASEDIR."phpqrcode/qrsplit.php";
include $QR_BASEDIR."phpqrcode/qrrscode.php";
include $QR_BASEDIR."phpqrcode/qrmask.php";
include $QR_BASEDIR."phpqrcode/qrencode.php";

defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends CI_Controller {
  public function __construct () {
      parent::__construct();
      $this->load->library('Qrcode');
  }
  public function Upi(){
    $upi_intent="upi://pay?pa=8780149265@apl&pn=errorcomments&am=1000&cu=INR";
    $path=FCPATH.'Files/upi.png';  // path to store qrcode
    QRcode::png($upi_intent,$path,3,5);    // qrcode in png format
  }
}
?>